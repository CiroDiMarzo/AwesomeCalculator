﻿./Disable_features.ps1

Start-Sleep -s 2

./Uninstall-remove.ps1

Start-Sleep -s 2

./Remove-Site.ps1