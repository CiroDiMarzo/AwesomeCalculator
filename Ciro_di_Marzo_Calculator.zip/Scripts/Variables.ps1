﻿$webApp = "http://spfarmciro-sp:2013/"

$site = "http://spfarmciro-sp:2013/sites/awesomecalc"

$literalPath = "C:\Users\ciro\Documents\Solutions\068-final_01\AwesomeCalculator.wsp"

$owner = "SPFarmCiro-SP\Ciro"