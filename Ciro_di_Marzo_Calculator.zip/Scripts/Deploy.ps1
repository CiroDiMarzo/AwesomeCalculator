﻿./Create-Site.ps1

Start-Sleep -s 2

./Add-Install.ps1

Start-Sleep -s 2

./Enable_features.ps1